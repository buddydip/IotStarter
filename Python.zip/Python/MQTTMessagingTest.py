# all configuration settings come from config.py
try:
	import config
except ImportError:
	print("Cannot open config.py"); exit();

import sys
import paho.mqtt.client as mqtt
import time

def on_connect(mqttc, obj, flags, rc):
	print("on_connect   - rc: " + str(rc))
	global is_connected
	is_connected = True

my_endpoint_url_path = "iotmmss0004936377trial.hanatrial.ondemand.com"
my_client_id = "d000-e000-v000-i000-c000-e001"
my_publish_topic = "iot/data/d000-e000-v000-i000-c000-e001"
my_password = "5657eb26a6c29fc2caec8a249cb138ae"

mqttc = mqtt.Client(client_id=my_client_id, transport='websockets')

mqttc.on_connect = on_connect

print(my_endpoint_url_path)

mqttc.username_pw_set(my_client_id, my_password)
mqttc.connect(my_endpoint_url_path)

mqttc.loop_start()

publish_interval=5

if is_connected == True:
        timestamp = int(time.time())

        # == START ==== fill the payload now - in this example we use the typical IoT Starterkit payload ====== 
        my_mqtt_payload='{"messageType":"m0t0y0p0e1","messages":[{'
        my_mqtt_payload=my_mqtt_payload + '"ParamName":"Distance", '
        my_mqtt_payload=my_mqtt_payload + '"ParamValue":"' + str(value) + '", '
        my_mqtt_payload=my_mqtt_payload + '"TimeStamp":' + str(timestamp)
        my_mqtt_payload=my_mqtt_payload + '}]}'
        # == END ====== fill the payload now - in this example we use the typical IoT Starterkit payload ====== 

        print(my_mqtt_payload)
        mqttc.publish(my_publish_topic, my_mqtt_payload, qos=0)
else:
        print("still waiting for connection")
        time.sleep(publish_interval)
